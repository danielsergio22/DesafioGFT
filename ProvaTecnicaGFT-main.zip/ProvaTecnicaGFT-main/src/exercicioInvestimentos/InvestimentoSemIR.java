package exercicioInvestimentos;

public class InvestimentoSemIR extends Investimento {

	public InvestimentoSemIR(double valorInicial, double jurosMensais) {
		super(valorInicial, jurosMensais);
		}

	@Override
	public double calcularLucro(int meses) {
		if (this.getValorInicial()<1000) {
			System.out.println("O valor inicial n�o pode ser menor que R$1000");
			return 0;
		}
		return super.calcularLucro(meses);
	}
	
	
	
}
