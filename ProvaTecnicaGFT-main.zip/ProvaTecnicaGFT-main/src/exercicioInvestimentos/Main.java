package exercicioInvestimentos;

public class Main {

	public static void main(String[] args) {
		InvestimentoComIR investimentoComIR= new InvestimentoComIR(4000.0, 1.2);
		InvestimentoSemIR investimentoSemIR= new InvestimentoSemIR(2000.0, 0.7);
		
		System.out.println(investimentoComIR.calcularLucro(17));
		System.out.println(investimentoSemIR.calcularLucro(10));
		
	}

}
