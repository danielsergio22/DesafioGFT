package exercicioInvestimentos;

public class InvestimentoComIR extends Investimento {

	public InvestimentoComIR(double valorInicial, double jurosMensais) {
		super(valorInicial, jurosMensais);
		}

	@Override
	public double calcularLucro(int meses) {
		if (meses<6) {
			return super.calcularLucro(meses)*0.775;//0,775 equivale ao valor do lucro descontado 22,5%
		}else if(meses>=6 && meses<12) {
			return super.calcularLucro(meses)*0.8;//0,8 equivale ao valor do lucro descontado 20%
		}else if(meses>=12 && meses<24) {
			return super.calcularLucro(meses)*0.825;//0,825 equivale ao valor do lucro descontado 17,5%
		}else 
			return super.calcularLucro(meses)*0.85;//0,85 equivale ao valor do lucro descontado 15%
			
	}
	
	
}
