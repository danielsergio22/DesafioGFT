package exercicioInvestimentos;

public abstract class Investimento {
	private double valorInicial;
	private double jurosMensais;
	
	
	
	public Investimento(double valorInicial, double jurosMensais) {
		this.valorInicial = valorInicial;
		this.jurosMensais = jurosMensais/100.0; // dividindo por 100 para transformar a porcentagem em taxa
	}

	public double calcularLucro(int meses) {
		double retorno=0;
		retorno = (valorInicial*(Math.pow(((1+jurosMensais)), meses)))-(valorInicial);
		return retorno;
	}

	public double getValorInicial() {
		return valorInicial;
	}

	public void setValorInicial(double valorInicial) {
		this.valorInicial = valorInicial;
	}

	public double getJurosMensais() {
		return jurosMensais;
	}

	public void setJurosMensais(double jurosMensais) {
		this.jurosMensais = jurosMensais;
	}
	
}
