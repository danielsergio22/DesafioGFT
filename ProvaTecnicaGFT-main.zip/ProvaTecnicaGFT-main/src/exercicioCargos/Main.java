package exercicioCargos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		List<Pessoa> pessoas = new ArrayList<>();
		Scanner scan = new Scanner(System.in);
		int contStarter=0;
		int contJunior=0;
		int contSenior=0;
		String cargo2;
		
		System.out.println("Controle de Funcion�rios");
		
		
		while(pessoas.size()<5) {
			System.out.print("Informe o nome da "+(pessoas.size()+1)+"� pessoa: ");
			String nome = scan.next();
			System.out.print("Informe o cargo da "+(pessoas.size()+1)+"� pessoa (Starter, Junior ou S�nior): ");
			String cargo = scan.next();
			
			if (!cargo.equalsIgnoreCase("Junior") && !cargo.equalsIgnoreCase("S�nior") && !cargo.equalsIgnoreCase("Starter")) {
				cargo2="S�nior";
			}else {
				cargo2=cargo;}
			
			pessoas.add(new Pessoa(nome,cargo2));
			
			if (cargo2.equalsIgnoreCase("Starter")) {
				contStarter++;
			}else if (cargo2.equalsIgnoreCase("Junior")) {
				contJunior++;
			}else {
				contSenior++;
			}
			
			
		}
		scan.close();
		System.out.println("Total de pessoas � "+pessoas.size());
		System.out.println("Starter: "+contStarter);
		System.out.println("Junior: "+contJunior);
		System.out.println("Senior: "+contSenior);
				
	}

}
