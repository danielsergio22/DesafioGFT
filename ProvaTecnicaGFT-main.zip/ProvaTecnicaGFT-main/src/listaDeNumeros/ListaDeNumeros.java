package listaDeNumeros;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ListaDeNumeros {

	public static void main(String[] args) {
		List <Integer> numeros = new ArrayList<>();
		Scanner scan = new Scanner(System.in);
		
		int acima10=0;
		int acima50=0;
		int numero;
		double soma=0;		
		while (numeros.size()<10) {
			System.out.print("Digite um n�mero: ");
			numero=(int)scan.nextDouble();
			if (numeros.contains(numero)) {
				while (numeros.contains(numero)){
					System.out.print("Voc� digitou um n�mero que j� existe. Digite outro: ");
					numero=(int)scan.nextDouble();
				}
			}
			numeros.add(numero);
			if (numero>10)
				acima10++;
			if (numero>50)
				acima50++;	
			soma+=numero;
		}
		System.out.println("O maior numero � "+Collections.max(numeros));
		System.out.println("O menor numero � "+Collections.min(numeros));
		
		System.out.println("A m�dia � "+soma/numeros.size());
			
		System.out.println("Tivemos "+acima10+" numeros acima de 10"+". Eles s�o:");
		numeros.stream().filter(n-> n > 10).forEach(System.out::println);
		
		System.out.println("Tivemos "+acima50+" numeros acima de 50" +". Eles s�o:");
		numeros.stream().filter(n-> n > 50).forEach(System.out::println);
		
		scan.close();
	}

}
