package exercicioMaiorNumerodaSequencia;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExercicioMaiorNumeroDaSequencia {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		List<Integer> numeros = new ArrayList<>();
		String stringNumeros;
		int maior = 0, soma = 0;

		System.out.println("digite uma sequ�ncia de n�meros separados por espa�o: ");
		stringNumeros = scan.nextLine();
		String[] stringNumerosSeparados = stringNumeros.split(" ");

		if (stringNumeros.equals(" ") || stringNumeros.equals("")) {
			System.out.println("Nenhum valor foi imputado");
		} else {

			int cont = 0;
			while (cont < stringNumerosSeparados.length) {
				int numero = Integer.parseInt(stringNumerosSeparados[cont]);
				numeros.add(numero);
				cont++;
				soma += numero;
				if (maior < numero) {
					maior = numero;
				}
			}
				System.out.println("O valor do maior n�mero � " + maior);
				System.out.println("A soma dos n�meros � " + soma);
			}
		
		scan.close();
	}

}
